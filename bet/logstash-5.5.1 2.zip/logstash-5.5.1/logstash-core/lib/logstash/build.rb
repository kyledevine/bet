# encoding: utf-8
BUILD_INFO = {"build_date"=>"2017-07-18T21:15:04Z", "build_sha"=>"4267263f454d5cfeb85d98cec4925c6aa28d230b", "build_snapshot"=>false}